FatSecretTest
=============

This is a sample project showing how to setup the Fat Secret API for Android.  It does the full 3-legged OAuth 1.0a login to get an access token and also shows how to do a basic search for foods.
