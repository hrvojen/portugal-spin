# Android-FatSecret-REST-API
Implementation of FatSecret REST API.  **foods.search** &amp; **foods.get**

**FatSecret** Java Android Example.

Response formats JSON &amp; XML.  This project returns JSON. 

[FaSecret REST API Documentation](http://platform.fatsecret.com/api/Default.aspx?screen=rapih)

[YouTube Video](https://youtu.be/bOOGQlR2G-s)

![Alt text](https://cloud.githubusercontent.com/assets/7454787/7188628/3edd1742-e447-11e4-888d-c6a2e0fef46e.PNG "Preview Search")
