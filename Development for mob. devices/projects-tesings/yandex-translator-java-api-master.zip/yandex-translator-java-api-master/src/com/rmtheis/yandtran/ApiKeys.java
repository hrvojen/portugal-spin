package com.rmtheis.yandtran;

public class ApiKeys {
  protected static final String YANDEX_API_KEY = "[Put your API key here]";
}
